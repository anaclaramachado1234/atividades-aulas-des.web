var v, p, r
v = prompt("Digite o valor da compra:")
p = prompt("Digite a quantidade de parcelas:")
r = v/p
alert("O valor de cada parcela vai ser de:"+r)
// Variaveis em JS
var frase
frase = "Aqui temos uma String"
alert(frase)// Para variavel não precisa usar aspas
// Fazendo entrada de dados para uma variavel 
var nome 
nome = prompt("Digite seu nome: ")
alert("Bem vindo "+nome)
var idade
idade = prompt("Digite sua idade: ")
alert("A idade é: "+ idade)
// Operações aritmeticas com JS
var n1, n2, r
n1=14
n2=20

r=n1+n2
alert("O calculo é:"+n1+"+"+n2+"="+r)//
// Considere os valores n1 e n2 sejam digitados pelo usuário
n1=parseInt(prompt("Digite o primeiro valor do próximo calculo:"))
n2=parseInt(prompt("Digite o segundo valor:"))
r=n1+n2
alert("O resultado da soma foi "+r)

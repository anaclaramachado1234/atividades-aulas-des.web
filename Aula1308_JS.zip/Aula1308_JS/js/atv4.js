var n, a, s
n=prompt("Digite o valor que deseja ver o antecessor e o sucessor:")
a=n-1
s=n+1
alert("O antecessor é: "+a+" e o sucessor é:"+s)
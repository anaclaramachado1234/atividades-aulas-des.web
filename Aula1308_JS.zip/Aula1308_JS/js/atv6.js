var km, L, r
km = prompt("Quantidade de km:")
L = prompt("Quantidade de L:")
r = km/L
alert("A média é:"+r)
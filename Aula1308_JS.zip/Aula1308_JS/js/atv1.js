var n1, n2, r
n1=prompt("Para ser realizado a conta. Digite o primeiro valor:")
n2=prompt("Agora digite o segundo valor:")
r=n1-n2
alert("O resultado da subtração é:"+r)
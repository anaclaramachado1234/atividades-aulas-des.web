// usuário digite o valor de uma compra e apresente o valor com 15% de acréscimo e o valor com 15% de desconto.
var c, a, d
c = Number(prompt("Informe o valor da compra:"))
a = c * 1.15
d = c * 0.85
alert("O valor com acréscimo será de: "+a)
alert("O valor com desconto será de:"+d)
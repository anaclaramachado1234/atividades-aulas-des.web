var n1, n2, n3, n4, s, m;

n1 = Number(prompt("Digite sua primeira nota:"));
n2 = Number(prompt("Digite sua segunda nota:"));
n3 = Number(prompt("Digite sua terceira nota:"));
n4 = Number(prompt("Digite sua quarta nota:"));

s = n1 + n2 + n3 + n4;
m = s / 4;

alert("O resultado da média é: " + m);
// b*h/2
var b, h, r
b=prompt("Digite o valor da base:")
h=prompt("Digite o valor da altura do triângulo:")
r=(b*h)/2
alert("O resultado da área é: "+r)
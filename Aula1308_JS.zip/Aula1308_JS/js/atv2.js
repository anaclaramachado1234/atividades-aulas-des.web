var n1, n2, n3, r
n1=prompt("Para a realização da multiplicação, insira o porimeiro valor:")
n2=prompt("Insira o segundo valor:")
n3=prompt("Insira o terceiro valor:")
r=n1*n2*n3
alert("Resultou em:"+r)
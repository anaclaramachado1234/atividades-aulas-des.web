var n
n=prompt("Digite o valor que deseja elevar ao cubo:")
r=n*n*n
alert("O resultado é:"+r)
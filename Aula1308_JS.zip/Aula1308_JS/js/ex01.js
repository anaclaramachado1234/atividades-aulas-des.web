// um aviso
alert("Scripot JS a partir de um arquivo externo")
// Confirmação, um pop it com Ok e cancelar de opção, Ok=Verdadeiro e Cancelar=Falso
confirm("O terceiro Info da manhã, é o melhor do ano de 2025 do periodo da manhã do IFPR da área de informática do Campus Irati!Is the best!!")


